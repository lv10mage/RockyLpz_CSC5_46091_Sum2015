/*
* File: main.cpp
* Author: Roque Lopez-Gutierrez
* Created on June 29, 2015, 12:00 PM
* Purpose: HW Savitch ch1 #8
*/

//System Libraries
#include <iostream> //File I/O
#include <iomanip>  //File iomanip
using namespace std; //std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(){
	//Declare Variables Here
    float Quart,Dime,Nick,Vquart,Vdime,Vnick,Cents;
	//Input Values Here
        cout<<"Press Enter After Input"<<endl;
        cout<<"Enter Number of Quarters = ";
        cin>>Quart;//Input quantity of quarters 
        cout<<"Enter Number of Dimes = ";
        cin>>Dime;//Input quantity of dimes
        cout<<"Enter Number of Nickels = ";
        cin>>Nick;//Input quantity of nickels
        //Process Input Here
	Vquart=Quart*.25;//Vquart is the value of quarters in $'s
        Vdime=Dime*.1;   //Vdime is the value of dimes in $'s
        Vnick=Nick*.05;  //Vnick is the value of nickels in $'s 
        Cents=Vquart+Vdime+Vnick;//Cents is the total value of coins in $'s
	//Output Unknowns Here
	cout<<"Total Value of coins = $"<<Cents<<setprecision (2)<<endl;
        //setprecision allows for code to display two decimal points
	//End of Code
	return 0;
}

