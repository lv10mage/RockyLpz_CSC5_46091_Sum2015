/* 
 * File:   main.cpp
 * Author: Roque Lopez-Gutierrez
 * Created on June 29, 2015, 7:54 AM
 * Purpose: HW CH1 Savitch,#4
 */

//System Libraries 
#include <iostream>
using namespace std;
//user libraries 

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables 
    int numpod,peapod,totpea;
    //input values
    cout<<"Hello\n";//Introduction added
    cout<<"Press return after entering a number.\n";//how to input value
    cout<<"Enter the number of pods:\n";//Enter value, a number which represents # of pea pods
    cin>>numpod;//input value
    cout<<"Enter the number of peas in a pod:\n";//Enter value, a number which represents # of peas in pod
    cin>>peapod;//input value
    //process input
    totpea=numpod+peapod;//Expression calculates total number of peas
    //plus sign added gives a logic error 
    //output unknowns 
    cout<<"If you have ";
    cout<<numpod;
    cout<<" pea pods\n";
    cout<<"and ";
    cout<<peapod;
    cout<<" peas in each pod, then\n";
    cout<<"you have ";
    cout<<totpea;
    cout<<" peas in all the pods.\n";
    cout<<"Good Bye";
    //End of code
    return 0;
}