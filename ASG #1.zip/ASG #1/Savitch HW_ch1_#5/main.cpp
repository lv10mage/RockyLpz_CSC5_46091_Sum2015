/*
* File: main.cpp
* Author: Roque Lopez-Gutierrez
* Created on June 29, 2015, 8:00 AM
* Purpose: HW CH1 Savitch,#5
*/

//System Libraries
#include <iostream> //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv){
//Declare Variables Here
    unsigned int CupCer,CupMil,BowCer,TubCer;
//Input Values Here
   cout<<"Press enter after inputing a value"<<endl;
   cout<<"Input the number Cups of Cereal = ";
   cin>>CupCer;//Input CupCer Cups of Cereal 
   cout<<"Input the number of Cups of Milk = ";
   cin>>CupMil;//Input CupMilk Cups of Milk
//Process Input Here
   BowCer=CupCer+CupMil;//BowCer Represents the Sum of CupCer and CupMil
   TubCer=CupCer*CupMil;//TubCer Representss the product of CupCer and CupMil
	
//Output Unknowns Here
	cout<<"Cups of Cereal and Cups of Milk = "<<BowCer<<endl;
        cout<<"Cups of Cereal times Cups of Milk = "<<TubCer;
//End of code 
	return 0;
}
