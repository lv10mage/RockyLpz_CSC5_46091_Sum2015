/* 
 * File:   main.cpp
 * Author: Roque Lopez-Gutierrez
 * Created on June 29, 2015, 9:18 AM
 * Purpose: HW CH1 Savitch,#6
 */

//System Libraries 
#include <iostream>
//Extra space in "< iostream>" gives an error
//leaving out a "<" or ">" will give an error
using namespace std;
//user libraries 

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //Excluding "int" will give an error
    //leaving out "main" or mispelling it will give an error
    //Excluding a "(" or ")" will give an error
    //mispelling an identifier will produce an error 
    //declare variables 
    int numpod,peapod,totpea;
    //input values
    cout<<"Hello\n";//Introduction added
    cout<<"Press return after entering a number.\n";//how to input value
    cout<<"Enter the number of pods:\n";//Enter value, a number which represents # of pea pods
    cin>>numpod;//input value
    cout<<"Enter the number of peas in a pod:\n";//Enter value, a number which represents # of peas in pod
    cin>>peapod;//input value
    //process input
    totpea=numpod*peapod;//Expression calculates total number of peas
    //output unknowns 
    cout<<"If you have ";
    cout<<numpod;
    cout<<" pea pods\n";
    cout<<"and ";
    cout<<peapod;
    cout<<" peas in each pod, then\n";
    cout<<"you have ";
    cout<<totpea;
    cout<<" peas in all the pods.\n";
    cout<<"Good Bye";
    //End of code
    //leaving out the "}" will produce an error
    return 0;
}