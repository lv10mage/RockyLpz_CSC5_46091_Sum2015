/* 
 * File:   main.cpp
 * Author: Roque Lopez-Gutierrez
 * Created on June 29, 2015, 7:20 PM
 * Purpose: HW CH1 Savitch,#7
 */

//System Libraries 
#include <iostream>
using namespace std;
//user libraries 

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
    //declare variables 
   
    //input values
    
    //process input
    
    //output unknowns 
cout<<"*******************************************************";
cout<<endl;
cout<<"        C C C                 S S S S         !!"<<endl;
cout<<"      C        C             S         S      !!"<<endl;
cout<<"    C                      S                  !!"<<endl;
cout<<"   C                        S                 !!"<<endl;
cout<<"   C                          S S S S         !!"<<endl;
cout<<"   C                                  S       !!"<<endl;
cout<<"    C                                   S     !!"<<endl;
cout<<"     C        C              S         S      "<<endl;
cout<<"       C C C                  S S S S         00"<<endl; 
cout<<endl;
cout<<"*******************************************************"<<endl; 
cout<<"       Computer Science is Cool Stuff!!!"<<endl;
    //End of code
    return 0;
}