/*
*File: Main.cpp
*Author: Roque Lopez-Gutierrez
*Created on June 23, 2015, 7:38
*Purpose: Homework, Free Fall
*/

//System Libraries
#include <iostream>//I/O Library
using namespace std;//Namespace for iostream

//User Librairies

//Global Constatns
const float GRAVITY= 3.21743e1f;//Acceleration Due to Gravity Earth (ft/sec^2)

//Function Prototypes

//Execution Begins Here
int main(int argc,char** argv) {
	//Declare Variables
	//dstnce=The Distance Dropped in (ft)
	//time=Time in (secs)
	float dstnce, time;
	//Prompt then Input the Time
	cout<<"To Calculate the Distance Dropped\n";
	cout<<"Input the Time in Seconds"<<endl;
	cout<<"Time should be in Floating Point format\n";
	cin>>time;
	//Calculate the free-fall distance
	//dstnce =1/2*GRAVITY*time*time;//Incorrect
	//dstnce =1.0f/2*GRAVITY*time*time;//Correct
	//dstnce =1/2.0f*GRAVITY*time*time;//Correct
	dstnce=GRAVITY*time*time/2;//Correct
	//Output the Results
	cout<<"The Distance Traveled = ";
	cout<<dstnce<<"(ft)"<<endl;
	//Exit Stage
	return 0;
}
