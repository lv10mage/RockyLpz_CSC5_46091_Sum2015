/*
* File: main.cpp
* Author: Roque Lopez-Gutierrez
* Created on June 23, 2015, 4:40 AM
* Purpose: First Program to Calculate a Paycheck
*/

//System Libraries
#include <iostream> //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
	//Declare Variable Here
	float hours,rate,pay;
	//Input Values Here
	hours=4e1f; //Hours Worked Units = hours
	rate=1e1f; //Pay Rate Unit = dollars/hour
	//Process Input Here
	pay=hours*rate; //Units = dollars
	//Output Uknowns Here
	cout<<"Hours Worked = "<<hours<<"(hrs)"<<endl;
	cout<<"Pay Rate     = $"<<rate<<"/(hrs)"<<endl;
	cout<<"My Paycheck  = $"<<pay<<endl;
	//Exit Stage Right
	return 0;
}

