/*
*File: Main.cpp
*Author: Roque Lopez-Gutierrez
*Created on June 23, 2015, 7:27
*Purpose: Homework, Energy Drinkers
*/

//System Libraries
#include <iostream> //I/O Library
using namespace std; //Namespace for iostream

//User Libraries

//Global Constants
const float CNVPCT=100.0f; //Conversion

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
	// Declare and Initialize Variables
	unsigned short cSurv=12467; //# of Customers Surveyed
	unsigned short nEDrnks;     //# of Customers Drinking 1 or more Energy Drinks per week
	unsigned short nCDrnks;     //# of Energy Drinkers that prefer Citrus Flavor
	float pEDrnks=0.14f;   //Percentage Surveyed that prefer Energy Drinks
	float pCDrnks=0.64f;   //Percentage of Energy Drinkers that Prefer Citrus Flavor
	//Calculate the Number of Drinkers
	nEDrnks=static_cast<int>(cSurv*pEDrnks);
	nCDrnks=static_cast<int>(nEDrnks*pCDrnks);
	//Output the Results
	cout<<"Number of Energy Drinkers = "<<nEDrnks<<endl;
	cout<<"Number of Citrus Drinkers = "<<nCDrnks<<endl;
	//End 
	return 0;
}