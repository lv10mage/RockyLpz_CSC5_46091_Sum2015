/*
*File: Main.cpp
*Author: Roque Lopez-Gutierrez
*Created on June 23, 2015, 8:43 PM
*Purpose: Homework, Millitary Budget
*/

//Systems Libraries 
#include <iostream>
using namespace std;//'Namespace for iostream

//User Libraries

//Global Constants 

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
	//Declare and Intitialize Variables 
	float MBdgt,ReBdgt,perc,total;
	//Input Values Here
	MBdgt=6.06e11f; //Military Budget in Billions
	ReBdgt=3.294e12f; //Remaining Federal Budget in Trillions
	total=3.8e12f; //Total Federal Budget in Trillions
	//Process Input Here
	perc=(MBdgt/total)*100; //Military Budget Percent of Total Federal Budget
	//Output Unknowns Here 
	cout<<"Military budget as a percentage = "<<perc<<"%"<<endl;
	//Exit
	return 0;
}
