/*
* File: main.cpp
* Author: Roque Lopez-Gutierrez
* Created June 26, 2015, 7:37AM
* Purpose: Lab, Gasoline Taxes
*/

//Systems Libraries
#include <iostream>
using namespace std;//Name Space for iostream
//User Libraries

//Global Constants
const unsigned char CNVPCT=100; 
//Function Prototypes

//Execution Begins Here
int main() {
	//Declare and Initialize Variables
	float fedTax,calTax,slsTax,gallon,Bgal,GalTax,PrGal,TotTax,TaxGas;
	//Input Values Here
	fedTax=0.18f; //Federal Tax $'s
	calTax=0.36f; //California Tax $'s
	slsTax=0.08f; //California Sales Tax %
	gallon=3.69f; //Price of a Gallon of Gas $'s all taxes include
	//Proces Input Here
	Bgal=gallon-fedTax-calTax;//Bgal = Price of a Gallon of Gas without fedTax and calTax
	GalTax=Bgal*slsTax;//GalTax = California Sales tax in $'s
	PrGal=Bgal-GalTax;//PrGal = Price of Gas without any Taxes
	TotTax=fedTax+calTax+GalTax;//TotTax = total tax in $'s
	TaxGas=TotTax/gallon*CNVPCT;//TaxGas = % of total Taxes on a Gallon of Gas
	//Output Unknowns Here
	cout<<"Base Price of a Gallon of Gasoline =$"<<PrGal<<endl;
	cout<<"Total Percent of Taxes on a Gallon of Gasoline = "<<TaxGas<<"%"<<endl;
	cout<<"Total Percent of Taxes Represent all Government Taxes on a gallon of Gasoline"<<endl;
	//Exit
	return 0;
}
