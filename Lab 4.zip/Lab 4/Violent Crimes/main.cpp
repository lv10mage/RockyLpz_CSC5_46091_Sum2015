/*
*File: Main.cpp
*Author: Roque Lopez-Gutierrez
*Created on June 27, 2015, 6:30AM
*Purpose: Lab 4, Violent Crimes
*/

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;//Namespace for iostream
//User Libraries

//Global Constants 
const unsigned char CNVPCT=100;//Global Constant Conversion to Percent 
//Function Prototypes

//Execution Begins Here
int main() {
	// Declare and Initialize Variables
	float UScrm,ENGcrm,USPer,ENGPer;
        int USpop;
	char ENGpop;
	//Input Values Here
	UScrm=11.88f;//US Violent Crimes in millions
	ENGcrm=6.52f;//English Violent Crimes in millions
	USpop=318;//US Population in millions
	ENGpop=64;//English Population in millions
	//Process Inputs Here
	USPer=UScrm/USpop*CNVPCT;//USPer=%
	ENGPer=ENGcrm/ENGpop*CNVPCT;//ENGPer=%
	//Output Unknowns
	cout<<"US Violent Crimes = "<<(round(USPer))<<"%"<<endl;
	cout<<"English Violent Crimes = "<<(round(ENGPer))<<"%"<<endl;
	//End of Code
	return 0;
}
